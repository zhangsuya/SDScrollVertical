//
//  SDMacro.h
//  SDScrollVertical
//
//  Created by Mac on 16/1/15.
//  Copyright © 2016年 suya. All rights reserved.
//

#ifndef SDMacro_h
#define SDMacro_h


#endif /* SDMacro_h */
//当前设备的宽高
#define kDeviceHeight [UIScreen mainScreen].bounds.size.height
#define kDeviceWidth  [UIScreen mainScreen].bounds.size.width
#define kStatusTableViewCellControlSpacing 10//控件间距
#define kStatusTableViewCellTextFontSize 14
#define HEIGHT_TWO_IMAG_WITH          (kDeviceWidth - 80 - 14 -16)/3

#define kDeviceHeight_No_NavigationHeight   (kDeviceHeight - 64)

#define selfWidth    self.view.frame.size.width
#define selfHeight    self.view.frame.size.height